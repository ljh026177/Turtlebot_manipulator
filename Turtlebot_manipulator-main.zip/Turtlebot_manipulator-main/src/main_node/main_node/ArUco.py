import cv2
import numpy as np

# 카메라 매트릭스 및 왜곡 계수 설정
camera_matrix = np.array([[673.65093354, 0.0, 461.37932431],
                          [0.0, 896.53354447, 292.972125],
                          [0.0, 0.0, 1.0]])

dist_coeffs = np.array([-0.24058224,  0.24173209, -0.00688234,  0.00100286, 0.28867522])

# ArUco 마커 사전 정의
aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_100)
aruco_params = cv2.aruco.DetectorParameters()

# 직선의 시각화 함수
def draw_line(image, camera_matrix, dist_coeffs, origin, direction, t_min, t_max, color, thickness):
    """
    직선을 주어진 방향으로 음/양 방향으로 확장하여 시각화합니다.
    :param image: 대상 이미지
    :param camera_matrix: 카메라 매트릭스
    :param dist_coeffs: 왜곡 계수
    :param origin: 직선이 지나는 한 점 (3D 좌표)
    :param direction: 직선의 방향 벡터 (단위 벡터가 아님)
    :param t_min: t 값의 최소값 (음수로 확장 가능)
    :param t_max: t 값의 최대값 (양수로 확장 가능)
    :param color: 직선 색상 (BGR)
    :param thickness: 직선 두께
    """
    # 시작점과 끝점 계산
    start_point = origin + t_min * direction
    end_point = origin + t_max * direction

    # 3D 좌표를 2D 픽셀 좌표로 투영
    start_pixel, _ = cv2.projectPoints(start_point, np.zeros(3), np.zeros(3), camera_matrix, dist_coeffs)
    end_pixel, _ = cv2.projectPoints(end_point, np.zeros(3), np.zeros(3), camera_matrix, dist_coeffs)

    # 픽셀 좌표로 변환
    start_pixel = tuple(start_pixel.ravel().astype(int))
    end_pixel = tuple(end_pixel.ravel().astype(int))

    # 직선을 이미지 상에 그리기
    cv2.line(image, start_pixel, end_pixel, color, thickness)

# 이미지 로드
img = cv2.imread('img/capture_20241128_181616.png')  # 이미지 파일 경로

if img is None:
    print("이미지를 불러올 수 없습니다. 경로를 확인하세요.")
    exit()

# ArUco 마커 검출
corners, ids, rejected = cv2.aruco.detectMarkers(img, aruco_dict, parameters=aruco_params)

if ids is not None:
    print(f"Detected markers: {len(ids)}")
    marker_length = 0.107  # 마커 크기 (미터)
    rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners, marker_length, camera_matrix, dist_coeffs)

    # 마커 데이터를 저장할 딕셔너리
    marker_data = {}

    # 마커 정보 출력 및 저장
    for i in range(len(ids)):
        marker_id = ids[i][0]
        marker_data[marker_id] = {
            "rvec": rvecs[i].flatten(),
            "tvec": tvecs[i].flatten()
        }
        print(f"Marker ID: {marker_id}")
        print(f"Rotation Vector (rvec): {rvecs[i].flatten()}")
        print(f"Translation Vector (tvec): {tvecs[i].flatten()}")

    # 특정 마커 기준으로 직선 계산 및 시각화
    if 1 in marker_data:
        # ID 1 기준 데이터 추출
        tvec1 = marker_data[1]["tvec"]
        rvec1 = marker_data[1]["rvec"]

        # 회전 행렬 및 방향 벡터 추출
        R1, _ = cv2.Rodrigues(rvec1)
        x_axis1 = R1[:, 0]  # ID 1 마커 기준 X축 벡터 (단위 벡터 아님)

        # 직선 시각화 (음/양 방향으로 확장)
        t_min, t_max = -5, 5  # 음의 방향과 양의 방향으로 확장
        draw_line(img, camera_matrix, dist_coeffs, tvec1, x_axis1, t_min, t_max, (255, 0, 0), 2)
    else:
        print("Marker with ID 1 not detected.")

else:
    print("No markers detected.")

# 결과 이미지 출력
cv2.imshow("Marker Detection with Extended Axis", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
