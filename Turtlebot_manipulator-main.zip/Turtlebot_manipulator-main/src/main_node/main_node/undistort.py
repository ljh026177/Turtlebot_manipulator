import numpy as np
import cv2 as cv
import glob

# termination criteria for corner refinement
criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)

# prepare object points (e.g., (0,0,0), (1,0,0), (2,0,0), ...)
objp = np.zeros((8 * 6, 3), np.float32)
objp[:, :2] = np.mgrid[0:6, 0:8].T.reshape(-1, 2)

# Arrays to store object points and image points
objpoints = []  # 3D points in real world space
imgpoints = []  # 2D points in image plane

# Load images
images = glob.glob('*.jpg')

for fname in images:
    img = cv.imread(fname)
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

    # Find the chess board corners
    ret, corners = cv.findChessboardCorners(gray, (6, 8), None)

    if ret:
        objpoints.append(objp)  # Add 3D points
        # Refine corner positions for greater accuracy
        corners2 = cv.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
        imgpoints.append(corners2)  # Add 2D points

        # Draw and display the corners
        cv.drawChessboardCorners(img, (6, 8), corners2, ret)
        cv.imshow('img', img)
        cv.waitKey(500)

cv.destroyAllWindows()

# Perform camera calibration
ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)

print("Camera matrix (mtx):\n", mtx)
print("Distortion coefficients (dist):\n", dist)

# Load an image to apply undistortion
img = cv.imread(images[0])  # 첫 번째 이미지 사용
h, w = img.shape[:2]

# Optimal camera matrix and ROI
newcameramtx, roi = cv.getOptimalNewCameraMatrix(mtx, dist, (w, h), 0, (w, h))

# Undistort the image
undistorted_img = cv.undistort(img, mtx, dist, None, newcameramtx)

# Crop the image based on ROI
x, y, w, h = roi
undistorted_img = undistorted_img[y:y+h, x:x+w]

# Save and display the undistorted image
cv.imwrite('calibresult.png', undistorted_img)
cv.imshow('Undistorted', undistorted_img)
cv.waitKey(0)
cv.destroyAllWindows()

# Reprojection error
mean_error = 0
for i in range(len(objpoints)):
    imgpoints2, _ = cv.projectPoints(objpoints[i], rvecs[i], tvecs[i], mtx, dist)
    error = cv.norm(imgpoints[i], imgpoints2, cv.NORM_L2) / len(imgpoints2)
    mean_error += error

print("Total reprojection error: {}".format(mean_error / len(objpoints)))
