import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
import cv2
import numpy as np


class LiveCameraPublisher(Node):
    def __init__(self):
        super().__init__('live_camera_publisher')
        self.cap = cv2.VideoCapture(0)
        # Create a publisher for CompressedImage
        self.publisher_ = self.create_publisher(CompressedImage, 'live_camera', 10)

        # Initialize OpenCV VideoCapture for the specific device (/dev/video2)
        self.cap = cv2.VideoCapture(2)  # USB 카메라 경로
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

        if not self.cap.isOpened():
            self.get_logger().error('Could not open camera at /dev/video2!')
            raise RuntimeError('Camera not accessible at /dev/video2.')

        # Timer for publishing frames at 30 Hz
        self.timer = self.create_timer(1.0 / 30.0, self.publish_frame)

        self.get_logger().info('Live camera publisher started on /dev/video2.')

    def publish_frame(self):
        ret, frame = self.cap.read()

        if not ret:
            self.get_logger().error('Failed to read frame from camera!')
            return

        # Convert frame to JPEG format
        _, buffer = cv2.imencode('.jpg', frame)

        # Create a CompressedImage message
        msg = CompressedImage()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.format = 'jpeg'
        msg.data = np.array(buffer).tobytes()

        # Publish the message
        self.publisher_.publish(msg)
        self.get_logger().debug('Published a frame.')

    def destroy_node(self):
        # Release the camera resource
        self.cap.release()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)

    try:
        live_camera = LiveCameraPublisher()
        rclpy.spin(live_camera)
    except KeyboardInterrupt:
        live_camera.get_logger().info('Live camera stopped manually.')
    finally:
        live_camera.destroy_node()
        rclpy.shutdown()
