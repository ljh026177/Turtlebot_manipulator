import cv2

cap = cv2.VideoCapture('/dev/video2')
if not cap.isOpened():
    print("Failed to open /dev/video2")
else:
    ret, frame = cap.read()
    if ret:
        print("Frame captured successfully!")
    else:
        print("Failed to read frame!")
cap.release()
