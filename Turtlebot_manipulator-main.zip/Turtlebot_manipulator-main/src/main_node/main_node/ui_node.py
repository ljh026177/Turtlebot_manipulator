import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QLineEdit, QPushButton, QLabel, QWidget
from PyQt5.QtCore import QTimer
from PyQt5.QtGui import QImage, QPixmap
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String
from threading import Thread, Lock
from main_node.main_ui import Ui_MainWindow, LoginWindow
import numpy as np
import cv2


# Button 상태 퍼블리셔
class ButtonStatePublisher(Node):
    def __init__(self):
        super().__init__('button_publisher')
        self.publisher = self.create_publisher(String, 'button_state', 10)

    def publish_button_click(self, button_name, button_action):
        msg = String()
        msg.data = f"{button_name} clicked"
        self.publisher.publish(msg)
        self.get_logger().info(f"Published: {msg.data}")




class LiveCameraSubscriber(Node):
    def __init__(self):
        super().__init__('live_camera_subscriber')
        self.subscription = self.create_subscription(
            CompressedImage,
            'live_camera',
            self.listener_callback,
            10
        )
        self.current_frame = None
        self.lock = Lock()  # 스레드 안전성을 위한 Lock

    def listener_callback(self, msg):
        with self.lock:
            np_arr = np.frombuffer(msg.data, np.uint8)
            self.current_frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)


class MainApp(QMainWindow, Ui_MainWindow):
    def __init__(self, user_id, button_publisher, live_camera_subscriber):
        super().__init__()
        self.setupUi(self)  # UI 설정
        self.live_camera_subscriber = live_camera_subscriber
        self.button_publisher = button_publisher

        self.idlabel.setText(f"ID: {user_id}")  # ID 표시
        self.init_buttons()

        # PyQt5 QTimer 설정 (30ms 간격으로 실행)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

    def update_frame(self):
        with self.live_camera_subscriber.lock:  # 스레드 안전하게 접근
            if self.live_camera_subscriber.current_frame is not None:
                frame = cv2.cvtColor(self.live_camera_subscriber.current_frame, cv2.COLOR_BGR2RGB)
                h, w, ch = frame.shape
                qimg = QImage(frame.data, w, h, ch * w, QImage.Format_RGB888)
                self.videolabel.setPixmap(QPixmap.fromImage(qimg))
            else:
                self.videolabel.setText("No frame received")  # 디버그 출력


    def init_buttons(self):
        # 버튼 이름과 객체 매핑
        self.buttons = {
            "Job 1": self.job1pushbutton,
            "Job 2": self.job2pushbutton,
            "Job 3": self.job3pushbutton,
            "Play": self.playpushbutton,
            "Stop": self.stoppushbutton,
            "Pause": self.pausepushbutton,
            "Resume": self.resumepushbutton,
            "Conveyor Play": self.playpushbutton_2,
            "Conveyor Stop": self.stoppushbutton_2,
        }

        # 버튼 클릭 이벤트 연결
        for button_name, button_obj in self.buttons.items():
            button_obj.clicked.connect(lambda _, name=button_name, obj=button_obj: self.handle_button_click(name, obj.text()))

    def handle_button_click(self, button_name, button_action):
        # ROS 2 토픽으로 버튼 클릭 이벤트 게시
        self.button_publisher.publish_button_click(button_name, button_action)

def main():
    # ROS 2 초기화
    rclpy.init()

    # ROS 퍼블리셔 노드 생성
    button_publisher = ButtonStatePublisher()
    live_camera = LiveCameraSubscriber()

    # PyQt5 애플리케이션 생성 및 실행
    app = QApplication(sys.argv)

    def on_login(user_id):
        # 로그인 성공 시 MainApp 초기화
        main_window = MainApp(user_id, button_publisher, live_camera)
        main_window.show()

    login_window = LoginWindow(on_login)  # 로그인 창 생성
    login_window.show()

    # ROS 2 스레드를 별도로 실행
    ros_thread = Thread(target=rclpy.spin, args=(live_camera,), daemon=True)
    ros_thread.start()

    sys.exit(app.exec_())
    button_publisher.destroy_node()
    live_camera.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
